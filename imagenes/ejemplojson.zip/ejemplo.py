import json

#ejemplo de escribir y leer en json 

class Persona:
    def __init__(self, nombre, apellido) -> None:
        self.nombre = nombre
        self.apellido = apellido


def leer(): #Para consultar
    listapersonas = []
    with open('archivo.json', 'r') as file:
        listapersonas = json.load(file)
    
    print(listapersonas)
    return listapersonas

def escribir(nombre, apellido): #Para agregar
    #Leer para agregar
    listapersonas = []
    with open('archivo.json', 'r') as file:
        listapersonas = json.load(file) #Devuelve una lista

    #Agregar
    nuevapersona = Persona(nombre, apellido)
    listapersonas.append(nuevapersona.__dict__)

    with open('archivo.json', 'w') as file:
        json.dump(listapersonas, file)

def modificar(nombremodificar, apellido): #Para modificar
    listapersonas = []
    with open('archivo.json', 'r') as file:
        listapersonas = json.load(file) 

    #Busqueda
    index = -1
    for i in range(0, len(listapersonas), 1):
        if(listapersonas[i]['nombre'] == nombremodificar):
            index = i

    if index == -1:
        print('nombre no conseguido')
    
    listapersonas[index]['apellido'] = apellido

    with open('archivo.json', 'w') as file:
        json.dump(listapersonas, file)


#leer()
#modificar('', '')
#escribir('', '')


    
 
        