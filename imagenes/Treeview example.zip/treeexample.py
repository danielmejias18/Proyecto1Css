import tkinter as tk
from tkinter import ttk
import json

class App:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Ejemplo tkk treeview")
        self.window.geometry("400x250+500+200")
        self.window.resizable(0, 0)

        self.buttonShowAllClients = tk.Button(self.window, width=40, text="Show all clients", command=self.ShowAllClients)
        self.buttonShowAllClients.place(x=50, y=100)

        tk.mainloop()

    def ShowAllClients(self):
        windowReport = tk.Toplevel()
        windowReport.title("Clients")
        windowReport.geometry("420x230+700+400")
        windowReport.resizable(0, 0)

        #Componente tree
        tree = ttk.Treeview()
        #Le indico que columnas quiero que tenga
        columns = ("code", "name")
        #Lo configuro
        tree = ttk.Treeview(windowReport, columns=columns, show='headings')

        #Text es como quiero que aparezca, lo otro es la variable de columns
        tree.heading("code", text='Codee')
        tree.heading("name", text='Namee')


        #esta es como un place
        tree.grid(row=0, column=0, sticky='nsew')

        #Agrego la scrollbar
        scrollbar = ttk.Scrollbar(windowReport, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky='ns')


        clients = []
        #Reading all clients
        with open(".\\clients.json","r") as file:
            data = json.load(file)
            for line in data:
                clients.append((line["code"], line["name"]))
        
        for client in clients:
            tree.insert('', tk.END, values=client)

       
        windowReport.mainloop()

def main():
    App()

if __name__ == "__main__":
    main()
    